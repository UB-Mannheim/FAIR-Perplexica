import { ChatOpenAI } from '@langchain/openai';
import { getGroqApiKey } from '../../config';
import logger from '../../utils/logger';

export const loadGroqChatModels = async () => {
  const groqApiKey = getGroqApiKey();

  if (!groqApiKey) return {};

  try {
    const chatModels = {
      'Llama 3.2 90B': new ChatOpenAI(
        {
          openAIApiKey: groqApiKey,
          modelName: 'llama-3.2-90b-text-preview',
          temperature: 0.3,
        },
        {
          baseURL: 'https://api.groq.com/openai/v1',
        },
      ),
      'Llama 3.2 1B': new ChatOpenAI(
        {
          openAIApiKey: groqApiKey,
          modelName: 'llama-3.2-1b-preview',
          temperature: 0.3,
        },
        {
          baseURL: 'https://api.groq.com/openai/v1',
        },
      ),
      'Llama 3.2 3B': new ChatOpenAI(
        {
          openAIApiKey: groqApiKey,
          modelName: 'llama-3.2-3b-preview',
          temperature: 0.3,
        },
        {
          baseURL: 'https://api.groq.com/openai/v1',
        },
      ),
      'Llama 3.1 70B': new ChatOpenAI(
        {
          openAIApiKey: groqApiKey,
          modelName: 'llama-3.1-70b-versatile',
          temperature: 0.7,
        },
        {
          baseURL: 'https://api.groq.com/openai/v1',
        },
      ),
      'Llama 3.1 8B': new ChatOpenAI(
        {
          openAIApiKey: groqApiKey,
          modelName: 'llama-3.1-8b-instant',
          temperature: 0.7,
        },
        {
          baseURL: 'https://api.groq.com/openai/v1',
        },
      ),
      'LLaMA3 8b': new ChatOpenAI(
        {
          openAIApiKey: groqApiKey,
          modelName: 'llama3-8b-8192',
          temperature: 0.7,
        },
        {
          baseURL: 'https://api.groq.com/openai/v1',
        },
      ),
      'LLaMA3 70b': new ChatOpenAI(
        {
          openAIApiKey: groqApiKey,
          modelName: 'llama3-70b-8192',
          temperature: 0.7,
        },
        {
          baseURL: 'https://api.groq.com/openai/v1',
        },
      ),
      'Mixtral 8x7b': new ChatOpenAI(
        {
          openAIApiKey: groqApiKey,
          modelName: 'mixtral-8x7b-32768',
          temperature: 0.7,
        },
        {
          baseURL: 'https://api.groq.com/openai/v1',
        },
      ),
      'Gemma 7b': new ChatOpenAI(
        {
          openAIApiKey: groqApiKey,
          modelName: 'gemma-7b-it',
          temperature: 0.7,
        },
        {
          baseURL: 'https://api.groq.com/openai/v1',
        },
      ),
      'Gemma2 9b': new ChatOpenAI(
        {
          openAIApiKey: groqApiKey,
          modelName: 'gemma2-9b-it',
          temperature: 0.7,
        },
        {
          baseURL: 'https://api.groq.com/openai/v1',
        },
      ),
    };

    return chatModels;
  } catch (err) {
    logger.error(`Error loading Groq models: ${err}`);
    return {};
  }
};
